package com.example.taskqasim;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    RadioButton rb1 , rb2,rb3,rb4,rb5;
    EditText txtWeight;
    RadioGroup G1;
    Button button;
    double val=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        G1=(RadioGroup)findViewById(R.id.G1);
        txtWeight=(EditText)findViewById(R.id.txtWeight);

    }

    public void Test(View v){
  
        int selectedId = G1.getCheckedRadioButtonId();
        rb1 = (RadioButton) findViewById(selectedId);


        double total = Double.parseDouble(txtWeight.getText().toString());


        switch (rb1.getId())
        {

            case R.id.rb1: val=(total*3.7)/9.8;break;

            case R.id.rb2:val=(total*3.711)/9.8;break;
            case R.id.rb3: val=(total*9.807)/9.8;break;

            case R.id.rb4 : val=(total*8.87)/9.8;break;
            case R.id.rb5 : val=(total*11.15)/9.8;break;

        }
        Toast.makeText(MainActivity.this,"val= "+ String.valueOf(val), Toast.LENGTH_SHORT).show();

    }




}

